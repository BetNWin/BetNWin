<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mobile = $_POST['mobile'];
    $otp = $_POST['otp'];

    // Normally here we check from database
    // But for now, accept any non-empty values
    if (!empty($mobile) && !empty($otp)) {
        // redirect to dashboard
        header("Location: ../dashboard.html");
        exit();
    } else {
        echo "<h2 style='color:red; text-align:center;'>Invalid mobile number or OTP!</h2>";
    }
} else {
    echo "Invalid Request!";
}
?>
