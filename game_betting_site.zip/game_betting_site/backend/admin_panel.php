<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.html");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Admin Panel</title>
</head>
<body>
  <h1>Welcome, Admin!</h1>
  <a href="backend/admin_logout.php">Logout</a>

  <h2>Pending Deposits</h2>
  <iframe src="backend/admin_approve.php?type=deposit" width="100%" height="300"></iframe>

  <h2>Pending Withdrawals</h2>
  <iframe src="backend/admin_approve.php?type=withdrawal" width="100%" height="300"></iframe>
</body>
</html>
