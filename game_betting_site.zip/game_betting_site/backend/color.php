<?php
$amount = $_POST['amount'] ?? 0;
$user_choice = $_POST['color'] ?? '';
$colors = ['red', 'green', 'yellow'];
$result = $colors[rand(0, 2)];

$status = ($user_choice === $result) ? 'win' : 'lose';

$data = [
    'game' => 'color',
    'amount' => $amount,
    'choice' => $user_choice,
    'result' => $result,
    'status' => $status,
    'time' => date('Y-m-d H:i:s')
];

file_put_contents('../data/games.txt', json_encode($data) . PHP_EOL, FILE_APPEND);

echo "<h2>🎨 Color Result: $result</h2>";
echo $status === 'win' ? "<h3>✅ You Win!</h3>" : "<h3>❌ Try Again!</h3>";
echo "<a href='../color.html'>Back</a>";
?>
