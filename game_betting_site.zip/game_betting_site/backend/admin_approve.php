<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Decide which type (deposit or withdrawal)
$type = $_GET['type'] ?? '';
$approveIndex = $_GET['approve'] ?? null;

if ($type !== 'deposit' && $type !== 'withdrawal') {
    echo "<h3>❌ Invalid type.</h3>";
    exit;
}

$file = "../data/" . $type . "s.txt";
$lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$updated = "";

if ($approveIndex !== null) {
    foreach ($lines as $index => $line) {
        $data = json_decode($line, true);
        if ($index == $approveIndex && !isset($data['approved'])) {
            $data['approved'] = true;
        }
        $updated .= json_encode($data) . PHP_EOL;
    }
    file_put_contents($file, $updated);
    header("Location: admin_approve.php?type=$type");
    exit;
}

// Display table
echo "<h2>Admin Approval - " . ucfirst($type) . "s</h2>";
echo "<table border='1' cellpadding='5'><tr>";

if ($type === 'deposit') {
    echo "<th>ID</th><th>Amount</th><th>UTR</th><th>Screenshot</th><th>Status</th><th>Action</th></tr>";
} else {
    echo "<th>ID</th><th>Amount</th><
