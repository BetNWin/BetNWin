<?php
error_reporting(E_ALL);
ini_set('display_errors', 1); // Show all PHP errors

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mobile = $_POST['mobile'] ?? '';
    $otp = $_POST['otp'] ?? '';

    if (!empty($mobile) && !empty($otp)) {
        $dataFolder = '../data/';
        $filePath = $dataFolder . 'users.txt';

        // Ensure folder exists
        if (!file_exists($dataFolder)) {
            mkdir($dataFolder, 0777, true);
        }

        // Save user data in JSON
        $user = [
            'mobile' => $mobile,
            'otp' => $otp,
            'created_at' => date("Y-m-d H:i:s")
        ];

        // Append JSON to file
        $save = file_put_contents($filePath, json_encode($user) . PHP_EOL, FILE_APPEND);

        if ($save !== false) {
            header('Location: ../register_success.html');
            exit;
        } else {
            echo "<h3>❌ Failed to write to file.</h3>";
        }
    } else {
        echo "<h3>❌ Please enter valid mobile number and OTP.</h3>";
    }
} else {
    echo "<h3>❌ Invalid request method.</h3>";
}
?>
