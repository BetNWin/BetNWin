<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = $_POST['amount'] ?? '';
    $upi_id = $_POST['upi_id'] ?? '';

    // Validation
    if ($amount >= 110 && $amount <= 500000 && !empty($upi_id)) {

        $filePath = '../data/withdrawals.txt';

        // Create data folder if not exists
        if (!file_exists('../data/')) {
            mkdir('../data/', 0777, true);
        }

        // Prepare withdrawal data
        $withdrawal = [
            'amount' => $amount,
            'upi_id' => $upi_id,
            'submitted_at' => date("Y-m-d H:i:s")
        ];

        // Save to file
        file_put_contents($filePath, json_encode($withdrawal) . PHP_EOL, FILE_APPEND);

        echo "<h3>✅ Withdrawal request submitted successfully!</h3>";
        echo "<a href='../dashboard.html'>Back to Dashboard</a>";

    } else {
        echo "<h3>❌ Invalid amount or UPI ID.</h3>";
    }

} else {
    echo "<h3>❌ Invalid Request</h3>";
}
?>
