<?php
session_start();

// Default credentials
$admin_user = "admin";
$admin_pass = "1234"; // Change this to a strong password

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';

    if ($user === $admin_user && $pass === $admin_pass) {
        $_SESSION['admin_logged_in'] = true;
        header("Location: ../admin_panel.php");
        exit;
    } else {
        echo "<h3>❌ Invalid credentials</h3>";
        echo "<a href='../admin_login.html'>Try again</a>";
    }
}
?>
